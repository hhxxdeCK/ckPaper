create definer = root@`%` event delete_expiration_data on schedule
    every '1' HOUR
        starts '2020-03-16 17:09:27'
    enable
    do
    UPDATE demo.notice SET demo.notice.is_active = 'N'
where TIMESTAMPDIFF(DAY,demo.notice.create_time,NOW()) > demo.notice.expiration_date;

